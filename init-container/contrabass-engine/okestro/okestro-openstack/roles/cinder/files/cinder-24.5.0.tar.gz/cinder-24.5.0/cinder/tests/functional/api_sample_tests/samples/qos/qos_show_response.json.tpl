{
    "qos_associations": []
}